'use strict';
// tinyslug-internal-7c1d: fold accents (NFD, drop combining marks), then hyphenate.
module.exports = function slug(text) {
  return String(text)
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
};
